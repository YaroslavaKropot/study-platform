package com.studyplatform.study_platrform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudyPlatrformApplicationTests {

	@Test
	void contextLoads() {
	}

}
