package com.studyplatform.study_platrform.controller;

import com.studyplatform.study_platrform.model.*;
import com.studyplatform.study_platrform.repository.*;
import com.studyplatform.study_platrform.service.NotificationService;
import com.studyplatform.study_platrform.dto.ResourceRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/groups/{groupId}/resources")
public class ResourceController {

    @Autowired
    private ResourceRepository resourceRepository;

    @Autowired
    private GroupRepository groupRepository; // Добавил

    @Autowired
    private UserRepository userRepository;   // Добавил

    @Autowired
    private NotificationService notificationService;

    @GetMapping
    public List<Resource> getGroupResources(@PathVariable Long groupId) {
        return resourceRepository.findByGroupId(groupId);
    }

    @GetMapping("/type/{type}")
    public List<Resource> getResourcesByType(@PathVariable Long groupId, @PathVariable ResourceType type) {
        return resourceRepository.findByGroupIdAndType(groupId, type);
    }
    // Добавь этот метод в твой ResourceController.java (бэкенд):
    @DeleteMapping("/{resourceId}")
    public ResponseEntity<Void> deleteResource(
            @PathVariable Long groupId,
            @PathVariable Long resourceId) {

        // 1. Проверить существование группы
        if (!groupRepository.existsById(groupId)) {
            return ResponseEntity.notFound().build();
        }

        // 2. Найти и удалить ресурс
        Resource resource = resourceRepository.findById(resourceId)
                .orElseThrow(() -> new RuntimeException("Ресурс не найден"));

        // 3. Проверить, что ресурс принадлежит этой группе
        if (!resource.getGroup().getId().equals(groupId)) {
            return ResponseEntity.badRequest().build();
        }

        // 4. Удалить ресурс
        resourceRepository.delete(resource);

        return ResponseEntity.noContent().build();
    }
    @PostMapping
    public ResponseEntity<Resource> createResource(
            @PathVariable Long groupId,
            @Valid @RequestBody ResourceRequest resourceRequest) {

        // 1. Найти группу
        Group group = groupRepository.findById(groupId)
                .orElseThrow(() -> new RuntimeException("Группа не найдена"));

        // 2. Найти пользователя (загрузившего ресурс)
        User uploadedBy = userRepository.findById(resourceRequest.getUploadedBy())
                .orElseThrow(() -> new RuntimeException("Пользователь не найден"));

        // 3. Создать ресурс
        Resource resource = new Resource();
        resource.setGroup(group);                // вместо setGroupId
        resource.setUploadedBy(uploadedBy);      // вместо setUploadedBy(Long)
        resource.setTitle(resourceRequest.getTitle());
        resource.setType(resourceRequest.getType());
        resource.setPathOrUrl(resourceRequest.getPathOrUrl());
        resource.setUploadedAt(LocalDateTime.now());

        Resource savedResource = resourceRepository.save(resource);

        // 4. Отправляем уведомление
        notificationService.notifyNewResource(
                groupId,
                savedResource.getTitle(),
                uploadedBy.getId() // или uploadedBy.getName()
        );

        return ResponseEntity.ok(savedResource);
    }
}