package com.studyplatform.study_platrform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudyPlatrformApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudyPlatrformApplication.class, args);
	}

}
