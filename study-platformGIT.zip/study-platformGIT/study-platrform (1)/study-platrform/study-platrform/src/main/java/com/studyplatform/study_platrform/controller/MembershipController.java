package com.studyplatform.study_platrform.controller;

import com.studyplatform.study_platrform.dto.MembershipRequest;
import com.studyplatform.study_platrform.model.*;
import com.studyplatform.study_platrform.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/groups/{groupId}/memberships")
public class MembershipController {

    @Autowired
    private MembershipRepository membershipRepository;

    @Autowired
    private GroupRepository groupRepository; // Добавил

    @Autowired
    private UserRepository userRepository;   // Добавил

    @GetMapping
    public List<Membership> getGroupMemberships(@PathVariable Long groupId) {
        return membershipRepository.findByGroupId(groupId);
    }

    @PostMapping
    public ResponseEntity<Membership> createMembership(
            @PathVariable Long groupId,
            @Valid @RequestBody MembershipRequest membershipRequest) { // Используем DTO

        // 1. Найти группу
        Group group = groupRepository.findById(groupId)
                .orElseThrow(() -> new RuntimeException("Группа не найдена"));

        // 2. Найти пользователя
        User user = userRepository.findById(membershipRequest.getUserId())
                .orElseThrow(() -> new RuntimeException("Пользователь не найден"));

        // 3. Проверить, не состоит ли уже пользователь в группе
        if (membershipRepository.existsByGroupAndUser(group, user)) {
            return ResponseEntity.badRequest().body(null);
        }

        // 4. Создать членство
        Membership membership = new Membership();
        membership.setGroup(group);        // Устанавливаем объект Group
        membership.setUser(user);          // Устанавливаем объект User
        membership.setRole(membershipRequest.getRole() != null ?
                membershipRequest.getRole() : MemberRole.MEMBER);
        membership.setJoinedAt(LocalDateTime.now());

        Membership saved = membershipRepository.save(membership);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{userId}/role")
    public ResponseEntity<Membership> updateMembershipRole(
            @PathVariable Long groupId,
            @PathVariable Long userId,
            @RequestParam MemberRole role) {

        // Найти группу и пользователя
        Group group = groupRepository.findById(groupId)
                .orElseThrow(() -> new RuntimeException("Группа не найдена"));
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Пользователь не найден"));

        // Найти членство
        Membership membership = membershipRepository.findByGroupAndUser(group, user)
                .orElseThrow(() -> new RuntimeException("Членство не найдено"));

        membership.setRole(role);
        Membership saved = membershipRepository.save(membership);
        return ResponseEntity.ok(saved);
    }

    @DeleteMapping("/{userId}")
    public ResponseEntity<Void> deleteMembership(
            @PathVariable Long groupId,
            @PathVariable Long userId) {

        // Найти группу и пользователя
        Group group = groupRepository.findById(groupId)
                .orElseThrow(() -> new RuntimeException("Группа не найдена"));
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Пользователь не найден"));

        // Найти и удалить членство
        Membership membership = membershipRepository.findByGroupAndUser(group, user)
                .orElseThrow(() -> new RuntimeException("Членство не найдено"));

        membershipRepository.delete(membership);
        return ResponseEntity.noContent().build();
    }
}