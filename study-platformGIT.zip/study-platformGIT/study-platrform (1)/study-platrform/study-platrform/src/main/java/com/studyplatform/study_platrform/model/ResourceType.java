package com.studyplatform.study_platrform.model;

public enum ResourceType {
    FILE,
    LINK,
    DOCUMENT,
    PRESENTATION
}
