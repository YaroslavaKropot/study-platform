package com.studyplatform.study_platrform.controller;

import com.studyplatform.study_platrform.model.*;
import com.studyplatform.study_platrform.repository.*;
import com.studyplatform.study_platrform.dto.TaskRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.time.LocalDateTime;

@RestController
@RequestMapping("/api")
public class TaskController {

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private GroupRepository groupRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/groups/{groupId}/tasks")
    public ResponseEntity<?> createTask(
            @PathVariable Long groupId,
            @Valid @RequestBody TaskRequest taskRequest) {

        // 1. Найти группу по ID
        Group group = groupRepository.findById(groupId)
                .orElseThrow(() -> new RuntimeException("Группа с ID " + groupId + " не найдена"));

        // 2. Найти пользователя-создателя по ID из запроса
        User creator = userRepository.findById(taskRequest.getCreatedBy())
                .orElseThrow(() -> new RuntimeException("Пользователь с ID " + taskRequest.getCreatedBy() + " не найден"));

        // 3. Создать задачу
        Task task = new Task();
        task.setGroup(group);
        task.setCreatedBy(creator);
        task.setTitle(taskRequest.getTitle());
        task.setDescription(taskRequest.getDescription());

        // 4. Установить статус задачи
        TaskStatus status;
        if (taskRequest.getStatus() != null && !taskRequest.getStatus().trim().isEmpty()) {
            try {
                status = TaskStatus.valueOf(taskRequest.getStatus().toUpperCase());
            } catch (IllegalArgumentException e) {
                status = TaskStatus.NEW; // Значение по умолчанию при ошибке
            }
        } else {
            status = TaskStatus.NEW; // Значение по умолчанию если статус не передан
        }
        task.setStatus(status);

        // 5. Установить дедлайн если есть
        if (taskRequest.getDeadline() != null) {
            task.setDeadline(taskRequest.getDeadline());
        }

        // 6. Установить дату создания (уже есть в конструкторе по умолчанию)
        task.setCreatedAt(LocalDateTime.now());

        // 7. Сохранить задачу
        Task savedTask = taskRepository.save(task);

        return ResponseEntity.ok(savedTask);
    }

    @GetMapping("/groups/{groupId}/tasks")
    public ResponseEntity<?> getGroupTasks(@PathVariable Long groupId) {
        // Проверяем существование группы
        if (!groupRepository.existsById(groupId)) {
            return ResponseEntity.status(404).body("Группа не найдена");
        }

        // Получаем задачи группы
        return ResponseEntity.ok(taskRepository.findByGroupId(groupId));
    }

    @PutMapping("/tasks/{taskId}")
    public ResponseEntity<?> updateTask(
            @PathVariable Long taskId,
            @Valid @RequestBody TaskRequest taskRequest) {

        // Найти задачу
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Задача с ID " + taskId + " не найдена"));

        // Обновить поля
        if (taskRequest.getTitle() != null) {
            task.setTitle(taskRequest.getTitle());
        }
        if (taskRequest.getDescription() != null) {
            task.setDescription(taskRequest.getDescription());
        }
        if (taskRequest.getStatus() != null) {
            try {
                task.setStatus(TaskStatus.valueOf(taskRequest.getStatus().toUpperCase()));
            } catch (IllegalArgumentException e) {
                // Если статус некорректный, не меняем его
            }
        }
        if (taskRequest.getDeadline() != null) {
            task.setDeadline(taskRequest.getDeadline());
        }

        Task updatedTask = taskRepository.save(task);
        return ResponseEntity.ok(updatedTask);
    }

    @DeleteMapping("/tasks/{taskId}")
    public ResponseEntity<?> deleteTask(@PathVariable Long taskId) {
        if (!taskRepository.existsById(taskId)) {
            return ResponseEntity.status(404).body("Задача не найдена");
        }

        taskRepository.deleteById(taskId);
        return ResponseEntity.ok("Задача удалена");
    }
}