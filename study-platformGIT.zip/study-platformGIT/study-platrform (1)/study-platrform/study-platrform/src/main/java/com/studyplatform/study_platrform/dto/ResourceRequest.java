package com.studyplatform.study_platrform.dto;

import com.studyplatform.study_platrform.model.ResourceType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class ResourceRequest {

    @NotBlank(message = "Название ресурса обязательно")
    private String title;

    @NotNull(message = "Тип ресурса обязателен")
    private ResourceType type;

    private String pathOrUrl;

    @NotNull(message = "ID загрузившего пользователя обязательно")
    private Long uploadedBy;

    // Геттеры и сеттеры
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public ResourceType getType() { return type; }
    public void setType(ResourceType type) { this.type = type; }

    public String getPathOrUrl() { return pathOrUrl; }
    public void setPathOrUrl(String pathOrUrl) { this.pathOrUrl = pathOrUrl; }

    public Long getUploadedBy() { return uploadedBy; }
    public void setUploadedBy(Long uploadedBy) { this.uploadedBy = uploadedBy; }
}