package com.studyplatform.study_platrform.service;

import com.studyplatform.study_platrform.dto.Notification;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    // Отправляет уведомление всем подписанным клиентам
    public void sendNotificationToAll(Notification notification) {
        messagingTemplate.convertAndSend("/topic/notifications", notification);
    }

    // Отправляет уведомление конкретной группе
    public void sendNotificationToGroup(Long groupId, Notification notification) {
        messagingTemplate.convertAndSend("/topic/group." + groupId, notification);
    }

    // Быстрые методы для частых уведомлений
    public void notifyNewTask(Long groupId, String taskTitle, Long createdBy) {
        Notification notification = new Notification(
                "NEW_TASK",
                "Создано новое задание: " + taskTitle,
                createdBy,
                groupId
        );
        sendNotificationToGroup(groupId, notification);
    }

    public void notifyNewResource(Long groupId, String resourceTitle, Long uploadedBy) {
        Notification notification = new Notification(
                "NEW_RESOURCE",
                "Загружен новый материал: " + resourceTitle,
                uploadedBy,
                groupId
        );
        sendNotificationToGroup(groupId, notification);
    }
}