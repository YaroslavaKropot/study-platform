package com.studyplatform.study_platrform.repository;

import com.studyplatform.study_platrform.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    // Spring Boot САМ реализует все основные методы!

    // JpaRepository<User, Long> означает:
    // - Работаем с объектами типа User (из твоего пакета model)
    // - ID имеет тип Long

    Optional<User> findByEmail(String email);
    boolean existsByEmail(String email);
}