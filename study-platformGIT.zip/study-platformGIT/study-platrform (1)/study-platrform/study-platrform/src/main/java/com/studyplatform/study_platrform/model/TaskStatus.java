package com.studyplatform.study_platrform.model;

public enum TaskStatus {
    NEW,
    IN_PROGRESS,
    COMPLETED
}
