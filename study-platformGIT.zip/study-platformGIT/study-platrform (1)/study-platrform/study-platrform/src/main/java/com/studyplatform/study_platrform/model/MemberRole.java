package com.studyplatform.study_platrform.model;

public enum MemberRole { ADMIN, MEMBER}
