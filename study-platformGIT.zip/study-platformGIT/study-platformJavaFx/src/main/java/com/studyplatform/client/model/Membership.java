package com.studyplatform.client.model;

import java.time.LocalDateTime;

public class Membership {
    private Long id;
    private Long groupId;        // Вместо Group object
    private Long userId;         // Вместо User object
    private String role;         // "ADMIN" или "MEMBER" (вместо enum)
    private LocalDateTime joinedAt;

    // Дополнительные поля для UI (не из бэкенда)
    private String groupName;
    private String userName;

    public Membership() {
        this.joinedAt = LocalDateTime.now();
        this.role = "MEMBER";
    }

    // Конструктор для создания нового членства
    public Membership(Long groupId, Long userId, String role) {
        this.groupId = groupId;
        this.userId = userId;
        this.role = (role != null && !role.isEmpty()) ? role : "MEMBER";
        this.joinedAt = LocalDateTime.now();
    }

    // Геттеры и сеттеры
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getGroupId() { return groupId; }
    public void setGroupId(Long groupId) { this.groupId = groupId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public LocalDateTime getJoinedAt() { return joinedAt; }
    public void setJoinedAt(LocalDateTime joinedAt) { this.joinedAt = joinedAt; }

    public String getGroupName() { return groupName; }
    public void setGroupName(String groupName) { this.groupName = groupName; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    // Вспомогательные методы
    public boolean isAdmin() {
        return "ADMIN".equalsIgnoreCase(role);
    }

    public boolean isMember() {
        return "MEMBER".equalsIgnoreCase(role);
    }

    public String getRoleDisplay() {
        return isAdmin() ? "Администратор" : "Участник";
    }

    @Override
    public String toString() {
        return "Membership{id=" + id + ", groupId=" + groupId + ", userId=" + userId +
                ", role='" + role + "', joinedAt=" + joinedAt + "}";
    }
}