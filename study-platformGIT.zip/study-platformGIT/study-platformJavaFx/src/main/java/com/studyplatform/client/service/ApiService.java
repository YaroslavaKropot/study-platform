package com.studyplatform.client.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.studyplatform.client.config.AppConfig;
import com.studyplatform.client.dto.*;
import com.studyplatform.client.model.*;
import java.net.http.*;
import java.net.URI;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;

public class ApiService {
    private static ApiService instance;
    private final HttpClient client;
    private final ObjectMapper mapper;

    private ApiService() {
        this.client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();

        this.mapper = new ObjectMapper();
        this.mapper.registerModule(new JavaTimeModule());
    }

    public static ApiService getInstance() {
        if (instance == null) {
            instance = new ApiService();
        }
        return instance;
    }

    // ===== ОБЩИЙ МЕТОД ДЛЯ ОТПРАВКИ ЗАПРОСОВ =====
    private HttpResponse<String> sendRequest(HttpRequest request) throws Exception {
        return client.send(request, HttpResponse.BodyHandlers.ofString());
    }

    // ===== АУТЕНТИФИКАЦИЯ =====
    public User login(String email, String password) throws Exception {
        LoginRequest request = new LoginRequest(email, password);
        String json = mapper.writeValueAsString(request);

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(AppConfig.LOGIN_URL))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        HttpResponse<String> res = sendRequest(req);

        if (res.statusCode() == 200) {
            User user = mapper.readValue(res.body(), User.class);
            SessionManager.getInstance().login(user);
            return user;
        } else {
            throw new Exception("Ошибка входа: " + res.statusCode() + " - " + res.body());
        }
    }

    public User register(String name, String email, String password) throws Exception {
        RegisterRequest request = new RegisterRequest(name, email, password);
        String json = mapper.writeValueAsString(request);

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(AppConfig.REGISTER_URL))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        HttpResponse<String> res = sendRequest(req);

        if (res.statusCode() == 200) {
            User user = mapper.readValue(res.body(), User.class);
            SessionManager.getInstance().login(user);
            return user;
        } else {
            String error = res.body();
            if (error.contains("Email уже используется")) {
                throw new Exception("Этот email уже зарегистрирован");
            }
            throw new Exception("Ошибка регистрации: " + error);
        }
    }

    public void logout() {
        SessionManager.getInstance().logout();
    }

    // ===== ГРУППЫ =====
    public List<Group> getGroups() throws Exception {
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(AppConfig.GROUPS_URL))
                .GET()
                .build();

        HttpResponse<String> res = sendRequest(req);

        if (res.statusCode() == 200) {
            Group[] groups = mapper.readValue(res.body(), Group[].class);
            return Arrays.asList(groups);
        } else {
            throw new Exception("Ошибка получения групп: " + res.statusCode());
        }
    }

    public Group createGroup(String name, String description) throws Exception {
        // Получаем текущего пользователя
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null) {
            throw new Exception("Пользователь не авторизован");
        }

        GroupRequest request = new GroupRequest(name, description, currentUser.getId());
        String json = mapper.writeValueAsString(request);

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(AppConfig.GROUPS_URL))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        HttpResponse<String> res = sendRequest(req);

        if (res.statusCode() == 200 || res.statusCode() == 201) {
            return mapper.readValue(res.body(), Group.class);
        } else {
            throw new Exception("Ошибка создания группы: " + res.statusCode());
        }
    }

    // ===== ЗАДАЧИ =====
    public List<Task> getGroupTasks(Long groupId) throws Exception {
        String url = AppConfig.API_URL + "/groups/" + groupId + "/tasks";

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .GET()
                .build();

        HttpResponse<String> res = sendRequest(req);

        if (res.statusCode() == 200) {
            Task[] tasks = mapper.readValue(res.body(), Task[].class);
            return Arrays.asList(tasks);
        } else {
            throw new Exception("Ошибка получения задач: " + res.statusCode());
        }
    }

    public Task createTask(Long groupId, String title, String description) throws Exception {
        String url = AppConfig.API_URL + "/groups/" + groupId + "/tasks";

        // Получаем текущего пользователя
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null) {
            throw new Exception("Пользователь не авторизован");
        }

        TaskRequest request = new TaskRequest(title, description);
        request.setCreatedBy(currentUser.getId());

        String json = mapper.writeValueAsString(request);

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        HttpResponse<String> res = sendRequest(req);

        if (res.statusCode() == 200 || res.statusCode() == 201) {
            return mapper.readValue(res.body(), Task.class);
        } else {
            throw new Exception("Ошибка создания задачи: " + res.statusCode());
        }
    }

    // ===== РЕСУРСЫ =====
    public List<Resource> getGroupResources(Long groupId) throws Exception {
        String url = AppConfig.GROUPS_URL + "/" + groupId + "/resources";

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .GET()
                .build();

        HttpResponse<String> res = sendRequest(req);

        if (res.statusCode() == 200) {
            Resource[] resources = mapper.readValue(res.body(), Resource[].class);
            return Arrays.asList(resources);
        } else {
            throw new Exception("Ошибка получения ресурсов: " + res.statusCode());
        }
    }

    public Resource createResource(ResourceRequest request) throws Exception {
        String url = AppConfig.GROUPS_URL + "/" + request.getGroupId() + "/resources";

        // Устанавливаем текущего пользователя как загрузившего
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser != null) {
            request.setUploadedBy(currentUser.getId());
        }

        String json = mapper.writeValueAsString(request);

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        HttpResponse<String> res = sendRequest(req);

        if (res.statusCode() == 200 || res.statusCode() == 201) {
            return mapper.readValue(res.body(), Resource.class);
        } else {
            throw new Exception("Ошибка создания ресурса: " + res.statusCode());
        }
    }
    public void deleteResource(Long groupId, Long resourceId) throws Exception {
        String url = AppConfig.GROUPS_URL + "/" + groupId + "/resources/" + resourceId;

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .DELETE()
                .build();

        HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());

        if (res.statusCode() != 200) {
            res.statusCode();
        }
    }

    // ===== УЧАСТНИКИ =====
    public List<Membership> getGroupMembers(Long groupId) throws Exception {
        String url = AppConfig.GROUPS_URL + "/" + groupId + "/memberships";

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .GET()
                .build();

        HttpResponse<String> res = sendRequest(req);

        if (res.statusCode() == 200) {
            Membership[] memberships = mapper.readValue(res.body(), Membership[].class);
            return Arrays.asList(memberships);
        } else {
            throw new Exception("Ошибка получения участников: " + res.statusCode());
        }
    }

    // ===== ПОЛЬЗОВАТЕЛЬ =====
    public User getCurrentUser() {
        return SessionManager.getInstance().getCurrentUser();
    }

    public boolean isLoggedIn() {
        return SessionManager.getInstance().isLoggedIn();
    }
}