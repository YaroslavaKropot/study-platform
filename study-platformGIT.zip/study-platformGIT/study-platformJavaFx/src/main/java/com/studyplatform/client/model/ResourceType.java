package com.studyplatform.client.model;

public enum ResourceType {
    FILE,
    LINK,
    DOCUMENT,
    PRESENTATION
}