package com.studyplatform.client.service;

import com.studyplatform.client.model.User;

public class SessionManager {
    private static SessionManager instance;
    private User currentUser;
    private String sessionId; // Будет храниться в cookies или localStorage

    private SessionManager() {}

    public static synchronized SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    public void login(User user) {
        this.currentUser = user;
        System.out.println("User logged in: " + user.getEmail());
    }

    public void logout() {
        this.currentUser = null;
        this.sessionId = null;
        System.out.println("User logged out");
    }

    public boolean isLoggedIn() {
        return currentUser != null;
    }

    public User getCurrentUser() { return currentUser; }
    public void setCurrentUser(User user) { this.currentUser = user; }

    public Long getUserId() {
        return currentUser != null ? currentUser.getId() : null;
    }

    public String getUserName() {
        return currentUser != null ? currentUser.getName() : "Гость";
    }

    public String getSessionId() { return sessionId; }
    public void setSessionId(String sessionId) { this.sessionId = sessionId; }
}