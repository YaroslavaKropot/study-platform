package com.studyplatform.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Group {
    private Long id;
    private String name;
    private String description;
    private String createdBy;  // ← ДОБАВЬ ЭТО ПОЛЕ
    private String createdAt;

    public Group() {}

    public Group(Long id, String name, String description, String createdBy, String createdAt) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.createdBy = createdBy;
        this.createdAt = createdAt;

    }

    // Геттеры и сеттеры
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getCreatedBy() { return createdBy; }  // ← ДОБАВЬ
    public void setCreatedBy(String createdBy) { this.createdBy = createdBy; }  // ← ДОБАВЬ

    public String getCreatedAt() { return createdAt; }  // ← ДОБАВЬ (если нужно)
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }  // ← ДОБАВЬ
}