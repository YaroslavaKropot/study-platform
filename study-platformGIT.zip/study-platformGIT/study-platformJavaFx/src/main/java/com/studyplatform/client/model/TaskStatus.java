package com.studyplatform.client.model;

public enum TaskStatus {
    NEW("Новая"),
    IN_PROGRESS("В процессе"),
    COMPLETED("Завершена");

    private final String displayName;

    TaskStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    // Метод для получения статуса из строки
    public static TaskStatus fromString(String status) {
        if (status == null) return NEW;

        switch (status.toUpperCase()) {
            case "NEW": return NEW;
            case "IN_PROGRESS": return IN_PROGRESS;
            case "COMPLETED": return COMPLETED;
            default: return NEW;
        }
    }
}