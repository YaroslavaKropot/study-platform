package com.studyplatform.client.service;

import com.studyplatform.client.config.AppConfig;
import com.studyplatform.client.dto.Notification;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import java.net.URI;

public class WebSocketService extends WebSocketClient {
    private static WebSocketService instance;
    private final ObjectMapper mapper = new ObjectMapper();

    private WebSocketService() {
        super(URI.create(AppConfig.WS_URL));
    }

    public static WebSocketService getInstance() {
        if (instance == null) {
            instance = new WebSocketService();
        }
        return instance;
    }

    @Override
    public void onOpen(ServerHandshake handshake) {
        System.out.println("✅ WebSocket connected");
    }

    @Override
    public void onMessage(String message) {
        try {
            Notification notification = mapper.readValue(message, Notification.class);
            System.out.println("🔔 Уведомление: " + notification.getMessage());

            // Можно показать alert пользователю
            showNotificationAlert(notification);

        } catch (Exception e) {
            System.out.println("📨 Сообщение: " + message);
        }
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        System.out.println("❌ WebSocket disconnected: " + reason);
    }

    @Override
    public void onError(Exception ex) {
        System.err.println("⚠️ WebSocket error:");
        ex.printStackTrace();
    }

    public void connectToServer() {
        if (!isOpen()) {
            connect();
        }
    }

    private void showNotificationAlert(Notification notification) {
        // Здесь можно добавить показ уведомления в JavaFX
        // Например, через Alert или специальное окно
        System.out.println("📢 Новое уведомление от WebSocket!");
        System.out.println("   Тип: " + notification.getType());
        System.out.println("   Сообщение: " + notification.getMessage());
    }
}