package com.studyplatform.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.time.LocalDateTime;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Resource {
    private Long id;
    private Long groupId;        // Упрощаем: вместо Group object храним только ID
    private Long uploadedById;   // Упрощаем: вместо User object храним только ID
    private String title;
    private String type;         // "LINK" или "FILE" (вместо enum ResourceType)
    private String pathOrUrl;
    private LocalDateTime uploadedAt;
    private String uploadedByName; // Для отображения имени пользователя

    public Resource() {
        this.uploadedAt = LocalDateTime.now();
    }

    // Конструктор для создания нового ресурса
    public Resource(String title, String type, String pathOrUrl, Long groupId, Long uploadedById) {
        this.title = title;
        this.type = type;
        this.pathOrUrl = pathOrUrl;
        this.groupId = groupId;
        this.uploadedById = uploadedById;
        this.uploadedAt = LocalDateTime.now();
    }

    // Геттеры и сеттеры
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getGroupId() { return groupId; }
    public void setGroupId(Long groupId) { this.groupId = groupId; }

    public Long getUploadedById() { return uploadedById; }
    public void setUploadedById(Long uploadedById) { this.uploadedById = uploadedById; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getPathOrUrl() { return pathOrUrl; }
    public void setPathOrUrl(String pathOrUrl) { this.pathOrUrl = pathOrUrl; }

    public LocalDateTime getUploadedAt() { return uploadedAt; }
    public void setUploadedAt(LocalDateTime uploadedAt) { this.uploadedAt = uploadedAt; }

    public String getUploadedByName() { return uploadedByName; }
    public void setUploadedByName(String uploadedByName) { this.uploadedByName = uploadedByName; }

    @Override
    public String toString() {
        return "Resource{id=" + id + ", title='" + title + "', type='" + type +
                "', uploadedAt=" + uploadedAt + "}";
    }

    // Вспомогательные методы
    public boolean isLink() {
        return "LINK".equalsIgnoreCase(type);
    }

    public boolean isFile() {
        return "FILE".equalsIgnoreCase(type);
    }

    public String getDisplayName() {
        if (isLink()) {
            return "🔗 " + title;
        } else {
            return "📎 " + title;
        }
    }
}