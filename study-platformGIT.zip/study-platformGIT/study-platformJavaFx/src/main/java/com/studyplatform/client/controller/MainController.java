package com.studyplatform.client.controller;

import com.studyplatform.client.model.User;
import com.studyplatform.client.model.Group;
import com.studyplatform.client.model.Task;
import com.studyplatform.client.service.ApiService;
import com.studyplatform.client.service.WebSocketService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.util.List;

public class MainController {
    @FXML private Label userLabel;
    @FXML private Button logoutButton;
    @FXML private ListView<String> groupsList;
    @FXML private ListView<String> tasksList;
    @FXML private Button createGroupButton;
    @FXML private Button viewTasksButton;
    @FXML private Button addTaskButton;
    @FXML private Button resourcesButton;
    @FXML private Button membersButton;

    private User currentUser;
    private ApiService apiService = ApiService.getInstance();
    private Long selectedGroupId;

    public void setUser(User user) {
        this.currentUser = user;
        userLabel.setText("Добро пожаловать, " + user.getName());
        loadGroups();
        connectWebSocket();
    }

    @FXML
    private void initialize() {
        setupEventHandlers();
    }

    private void setupEventHandlers() {
        logoutButton.setOnAction(e -> logout());
        createGroupButton.setOnAction(e -> createGroup());
        viewTasksButton.setOnAction(e -> viewTasks());
        addTaskButton.setOnAction(e -> addTask());
        resourcesButton.setOnAction(e -> viewResources());
        membersButton.setOnAction(e -> viewMembers());

        groupsList.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldVal, newVal) -> onGroupSelected(newVal)
        );
    }

    private void connectWebSocket() {
        try {
            WebSocketService ws = WebSocketService.getInstance();
            ws.connectToServer();
            System.out.println("WebSocket подключен");
        } catch (Exception e) {
            System.out.println("WebSocket не подключен: " + e.getMessage());
        }
    }

    private void loadGroups() {
        try {
            List<Group> groups = apiService.getGroups();
            groupsList.getItems().clear();

            for (Group group : groups) {
                groupsList.getItems().add("📚 " + group.getName());
            }
        } catch (Exception e) {
            showAlert("Ошибка загрузки групп: " + e.getMessage());
        }
    }

    private void onGroupSelected(String groupName) {
        if (groupName != null) {
            // Находим ID выбранной группы
            try {
                List<Group> groups = apiService.getGroups();
                for (Group group : groups) {
                    if (("📚 " + group.getName()).equals(groupName)) {
                        selectedGroupId = group.getId();
                        loadTasks(group.getId());
                        break;
                    }
                }
            } catch (Exception e) {
                showAlert("Ошибка: " + e.getMessage());
            }
        }
    }

    private void loadTasks(Long groupId) {
        try {
            List<Task> tasks = apiService.getGroupTasks(groupId);
            tasksList.getItems().clear();

            for (Task task : tasks) {
                String icon = "";
                switch (task.getStatus()) {
                    case NEW: icon = "🆕 "; break;
                    case IN_PROGRESS: icon = "⚙️ "; break;
                    case COMPLETED: icon = "✅ "; break;
                }
                tasksList.getItems().add(icon + task.getTitle());
            }
        } catch (Exception e) {
            showAlert("Ошибка загрузки задач: " + e.getMessage());
        }
    }

    private void createGroup() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Создание группы");
        dialog.setHeaderText("Создать новую учебную группу");
        dialog.setContentText("Введите название группы:");

        dialog.showAndWait().ifPresent(groupName -> {
            if (!groupName.trim().isEmpty()) {
                try {
                    Group group = apiService.createGroup(groupName.trim(), "Описание группы");
                    loadGroups();
                    showAlert("Группа создана: " + group.getName());
                } catch (Exception e) {
                    showAlert("Ошибка: " + e.getMessage());
                }
            }
        });
    }

    private void viewTasks() {
        if (selectedGroupId == null) {
            showAlert("Выберите группу");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/studyplatform/client/views/task-view.fxml")
            );
            Parent root = loader.load();

            TaskController controller = loader.getController();
            Group group = new Group();
            group.setId(selectedGroupId);
            group.setName("Группа");
            controller.setGroup(group);

            Stage stage = new Stage();
            stage.setScene(new Scene(root, 600, 400));
            stage.setTitle("Задачи группы");
            stage.show();

        } catch (Exception e) {
            showAlert("Ошибка: " + e.getMessage());
        }
    }

    private void addTask() {
        if (selectedGroupId == null) {
            showAlert("Выберите группу");
            return;
        }

        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Добавление задачи");
        dialog.setHeaderText("Добавить задачу в группу");
        dialog.setContentText("Введите название задачи:");

        dialog.showAndWait().ifPresent(taskTitle -> {
            if (!taskTitle.trim().isEmpty()) {
                try {
                    Task task = apiService.createTask(selectedGroupId, taskTitle.trim(), "Описание задачи");
                    loadTasks(selectedGroupId);
                    showAlert("Задача добавлена: " + task.getTitle());
                } catch (Exception e) {
                    showAlert("Ошибка: " + e.getMessage());
                }
            }
        });
    }

    private void viewResources() {
        if (selectedGroupId == null) {
            showAlert("Выберите группу");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/studyplatform/client/views/resource-view.fxml")
            );
            Parent root = loader.load();

            ResourceController controller = loader.getController();
            Group group = new Group();
            group.setId(selectedGroupId);
            group.setName("Группа");
            controller.setGroup(group);

            Stage stage = new Stage();
            stage.setScene(new Scene(root, 600, 400));
            stage.setTitle("Материалы группы");
            stage.show();

        } catch (Exception e) {
            showAlert("Ошибка: " + e.getMessage());
        }
    }

    private void viewMembers() {
        if (selectedGroupId == null) {
            showAlert("Выберите группу");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/studyplatform/client/views/membership-view.fxml")
            );
            Parent root = loader.load();

            MembershipController controller = loader.getController();
            Group group = new Group();
            group.setId(selectedGroupId);
            group.setName("Группа");
            controller.setGroup(group);

            Stage stage = new Stage();
            stage.setScene(new Scene(root, 600, 400));
            stage.setTitle("Участники группы");
            stage.show();

        } catch (Exception e) {
            showAlert("Ошибка: " + e.getMessage());
        }
    }

    private void logout() {
        try {
            apiService.logout();

            // Возврат к окну входа
            Parent root = FXMLLoader.load(
                    getClass().getResource("/com/studyplatform/client/views/login.fxml")
            );
            Stage stage = (Stage) logoutButton.getScene().getWindow();
            stage.setScene(new Scene(root, 400, 350));

        } catch (Exception e) {
            showAlert("Ошибка выхода: " + e.getMessage());
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText(message);
        alert.show();
    }
}