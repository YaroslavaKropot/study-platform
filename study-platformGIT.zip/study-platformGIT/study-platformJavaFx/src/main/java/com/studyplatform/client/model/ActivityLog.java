package com.studyplatform.client.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ActivityLog {
    private Long id;
    private Long userId;
    private String action;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    private LocalDateTime timestamp;

    private String details;
    private String userName; // Дополнительное поле для UI

    public ActivityLog() {
        this.timestamp = LocalDateTime.now();
    }

    public ActivityLog(Long userId, String action, String details) {
        this.userId = userId;
        this.action = action;
        this.details = details;
        this.timestamp = LocalDateTime.now();
    }

    // Геттеры и сеттеры
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public String getDetails() { return details; }
    public void setDetails(String details) { this.details = details; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    // Вспомогательные методы
    public String getTimestampDisplay() {
        if (timestamp == null) return "";

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");
        return timestamp.format(formatter);
    }

    public String getActionDisplay() {
        if (action == null) return "";

        // Можно добавить локализацию действий
        switch (action.toUpperCase()) {
            case "LOGIN": return "Вход в систему";
            case "REGISTER": return "Регистрация";
            case "CREATE_TASK": return "Создание задачи";
            case "UPDATE_TASK": return "Обновление задачи";
            case "CREATE_GROUP": return "Создание группы";
            case "JOIN_GROUP": return "Вступление в группу";
            case "UPLOAD_RESOURCE": return "Загрузка материала";
            default: return action;
        }
    }

    @Override
    public String toString() {
        return "ActivityLog{id=" + id + ", userId=" + userId + ", action='" + action +
                "', timestamp=" + getTimestampDisplay() + "}";
    }
}