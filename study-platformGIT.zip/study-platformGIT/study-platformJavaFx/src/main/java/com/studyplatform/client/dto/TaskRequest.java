package com.studyplatform.client.dto;

public class TaskRequest {
    private String title;
    private String description;
    private Long createdBy; // ДОБАВЬ ЭТО

    public TaskRequest() {}

    public TaskRequest(String title, String description) {
        this.title = title;
        this.description = description;
    }

    // Геттеры и сеттеры
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    // ДОБАВЬ ЭТИ ДВА МЕТОДА:
    public Long getCreatedBy() { return createdBy; }
    public void setCreatedBy(Long createdBy) { this.createdBy = createdBy; }
}