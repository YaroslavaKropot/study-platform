package com.studyplatform.client.config;

public class AppConfig {
    // Базовые URL
    public static final String BASE_URL = "http://localhost:8080";
    public static final String API_URL = BASE_URL + "/api";

    // Endpoints пользователей
    public static final String LOGIN_URL = API_URL + "/users/login";
    public static final String REGISTER_URL = API_URL + "/users/register";
    public static final String USERS_URL = API_URL + "/users";

    // Группы (предположительные endpoints)
    public static final String GROUPS_URL = API_URL + "/groups";

    // Задачи (предположительные endpoints)
    public static final String TASKS_URL = API_URL + "/tasks";

    // Ресурсы (предположительные endpoints)
    public static final String RESOURCES_URL = API_URL + "/resources";

    // WebSocket
    public static final String WS_URL = "ws://localhost:8080/ws";

    // Таймауты
    public static final int CONNECT_TIMEOUT_SECONDS = 10;
    public static final int READ_TIMEOUT_SECONDS = 30;

    // Настройки UI
    public static final int WINDOW_WIDTH = 1024;
    public static final int WINDOW_HEIGHT = 768;
    public static final int LOGIN_WINDOW_WIDTH = 400;
    public static final int LOGIN_WINDOW_HEIGHT = 350;
}