package com.studyplatform.client.service;

import com.studyplatform.client.dto.Notification;
import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

import java.util.ArrayList;
import java.util.List;

public class NotificationService {
    private static NotificationService instance;
    private final List<Notification> notifications = new ArrayList<>();
    private NotificationListener listener;

    public interface NotificationListener {
        void onNewNotification(Notification notification);
        void onNotificationCountChanged(int count);
    }

    private NotificationService() {}

    public static synchronized NotificationService getInstance() {
        if (instance == null) {
            instance = new NotificationService();
        }
        return instance;
    }

    public void setListener(NotificationListener listener) {
        this.listener = listener;
    }

    public void addNotification(Notification notification) {
        notifications.add(notification);

        // Уведомляем слушателя
        if (listener != null) {
            Platform.runLater(() -> {
                listener.onNewNotification(notification);
                listener.onNotificationCountChanged(notifications.size());
            });
        }

        // Показываем alert (опционально)
        showAlertNotification(notification);
    }

    public List<Notification> getNotifications() {
        return new ArrayList<>(notifications);
    }

    public int getUnreadCount() {
        return notifications.size();
    }

    public void clearNotifications() {
        notifications.clear();
        if (listener != null) {
            listener.onNotificationCountChanged(0);
        }
    }

    private void showAlertNotification(Notification notification) {
        Platform.runLater(() -> {
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Новое уведомление");
            alert.setHeaderText("Study Platform");
            alert.setContentText(notification.getMessage());
            alert.show();
        });
    }

    public void markAsRead(int index) {
        if (index >= 0 && index < notifications.size()) {
            // Можно добавить флаг "прочитано" если нужно
            notifications.remove(index);
            if (listener != null) {
                listener.onNotificationCountChanged(notifications.size());
            }
        }
    }
}