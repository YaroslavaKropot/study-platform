package com.studyplatform.client.controller;

import com.studyplatform.client.model.Group;
import com.studyplatform.client.model.Membership;
import com.studyplatform.client.service.ApiService;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.util.List;

public class MembershipController {
    @FXML private ListView<String> membersListView;
    @FXML private Label groupLabel;
    @FXML private Button addMemberButton;
    @FXML private Button removeMemberButton;
    @FXML private Button makeAdminButton;
    @FXML private Button backButton;

    private ApiService apiService = ApiService.getInstance();
    private Long currentGroupId;
    private ObservableList<Membership> memberships = FXCollections.observableArrayList();

    public void setGroup(Group group) {
        this.currentGroupId = group.getId();
        groupLabel.setText("Участники: " + group.getName());
        loadMembers();
    }

    @FXML
    private void initialize() {
        setupListView();
    }

    private void setupListView() {
        membersListView.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldVal, newVal) -> {
                    boolean hasSelection = newVal != null;
                    removeMemberButton.setDisable(!hasSelection);
                    makeAdminButton.setDisable(!hasSelection);
                }
        );

        removeMemberButton.setDisable(true);
        makeAdminButton.setDisable(true);
    }

    private void loadMembers() {
        try {
            // TODO: Добавить метод getGroupMembers в ApiService
            // List<Membership> loaded = apiService.getGroupMembers(currentGroupId);
            // memberships.setAll(loaded);

            // Заглушка для теста
            List<Membership> mockMembers = createMockMembers();
            memberships.setAll(mockMembers);

            updateListView();

        } catch (Exception e) {
            showAlert("Ошибка загрузки: " + e.getMessage());
        }
    }

    private List<Membership> createMockMembers() {
        Membership m1 = new Membership();
        m1.setUserId(1L);
        m1.setUserName("Иван Иванов");
        m1.setRole("ADMIN");

        Membership m2 = new Membership();
        m2.setUserId(2L);
        m2.setUserName("Петр Петров");
        m2.setRole("MEMBER");

        Membership m3 = new Membership();
        m3.setUserId(3L);
        m3.setUserName("Мария Сидорова");
        m3.setRole("MEMBER");

        return List.of(m1, m2, m3);
    }

    private void updateListView() {
        ObservableList<String> items = FXCollections.observableArrayList();
        for (Membership m : memberships) {
            String roleIcon = "ADMIN".equals(m.getRole()) ? "👑 " : "👤 ";
            items.add(roleIcon + m.getUserName() + " (" + m.getRoleDisplay() + ")");
        }
        membersListView.setItems(items);
    }

    @FXML
    private void addMember() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Добавить участника");
        dialog.setHeaderText("Добавить пользователя в группу");
        dialog.setContentText("Введите email пользователя:");

        dialog.showAndWait().ifPresent(email -> {
            if (!email.trim().isEmpty()) {
                try {
                    // TODO: Добавить метод addMemberToGroup в ApiService
                    showAlert("Добавлен пользователь: " + email);
                    loadMembers();
                } catch (Exception e) {
                    showAlert("Ошибка: " + e.getMessage());
                }
            }
        });
    }

    @FXML
    private void removeMember() {
        int index = membersListView.getSelectionModel().getSelectedIndex();
        if (index >= 0 && index < memberships.size()) {
            Membership member = memberships.get(index);

            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Удаление");
            confirm.setContentText("Удалить '" + member.getUserName() + "' из группы?");

            if (confirm.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
                try {
                    // TODO: Добавить метод removeMemberFromGroup в ApiService
                    showAlert("Участник удален: " + member.getUserName());
                    loadMembers();
                } catch (Exception e) {
                    showAlert("Ошибка удаления: " + e.getMessage());
                }
            }
        }
    }

    @FXML
    private void makeAdmin() {
        int index = membersListView.getSelectionModel().getSelectedIndex();
        if (index >= 0 && index < memberships.size()) {
            Membership member = memberships.get(index);

            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Назначение администратором");
            confirm.setContentText("Назначить '" + member.getUserName() + "' администратором?");

            if (confirm.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
                try {
                    // TODO: Добавить метод changeMemberRole в ApiService
                    member.setRole("ADMIN");
                    updateListView();
                    showAlert("Теперь администратор: " + member.getUserName());
                } catch (Exception e) {
                    showAlert("Ошибка: " + e.getMessage());
                }
            }
        }
    }

    @FXML
    private void goBack() {
        try {
            backButton.getScene().getWindow().hide();
        } catch (Exception e) {
            showAlert("Ошибка: " + e.getMessage());
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText(message);
        alert.show();
    }
}