package com.studyplatform.client.model;

public enum MemberRole {
    ADMIN,
    MEMBER
}